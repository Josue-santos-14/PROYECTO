package com.proyectoprogamacion.proyecto.dao;

import com.proyectoprogamacion.proyecto.models.Usuario;

import java.util.List;

public interface UsuarioDao {

    List<Usuario> getUsuarios();

}
